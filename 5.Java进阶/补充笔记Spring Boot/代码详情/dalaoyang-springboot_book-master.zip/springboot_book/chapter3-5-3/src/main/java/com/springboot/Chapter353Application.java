package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter353Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter353Application.class, args);
	}

}
