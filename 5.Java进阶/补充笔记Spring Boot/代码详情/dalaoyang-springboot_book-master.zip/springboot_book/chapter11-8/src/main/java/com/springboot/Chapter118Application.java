package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter118Application {

    public static void main(String[] args) {
        SpringApplication.run(Chapter118Application.class, args);
    }

}

