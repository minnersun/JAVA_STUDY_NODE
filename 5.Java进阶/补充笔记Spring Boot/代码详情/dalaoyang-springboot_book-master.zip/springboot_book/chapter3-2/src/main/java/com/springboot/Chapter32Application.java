package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter32Application {

    public static void main(String[] args) {
        SpringApplication.run(Chapter32Application.class, args);
    }
}
