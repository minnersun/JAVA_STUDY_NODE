package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter102Application {

    public static void main(String[] args) {
        SpringApplication.run(Chapter102Application.class, args);
    }

}

