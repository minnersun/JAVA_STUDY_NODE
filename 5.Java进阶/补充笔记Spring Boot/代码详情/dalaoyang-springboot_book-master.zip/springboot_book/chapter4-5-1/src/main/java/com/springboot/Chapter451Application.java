package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter451Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter451Application.class, args);
	}

}
