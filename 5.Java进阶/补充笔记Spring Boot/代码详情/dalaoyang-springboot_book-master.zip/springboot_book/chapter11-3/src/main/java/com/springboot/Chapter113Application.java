package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter113Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter113Application.class, args);
	}

}

