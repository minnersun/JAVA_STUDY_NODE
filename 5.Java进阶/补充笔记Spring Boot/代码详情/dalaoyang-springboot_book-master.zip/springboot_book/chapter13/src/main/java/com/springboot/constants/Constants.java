package com.springboot.constants;

public class Constants {
    public static final Integer YES = 1;
    public static final Integer NO = 0;
    public static final int defaultPageSize = 10;

}
