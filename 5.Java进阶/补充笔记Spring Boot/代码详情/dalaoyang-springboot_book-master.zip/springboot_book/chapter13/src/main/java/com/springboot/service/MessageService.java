package com.springboot.service;

import com.springboot.entity.Message;

public interface MessageService {

    void saveMessage(Message message);
}
